$( document ).ready(function() {     
    /*show first tab on page load*/
    $('.accordion .card:first .btn-link').click();
    $('.accordion .card .btn-link').click(function(){
        var mainBox = $(this).attr('data-target');
        animationScroll($(this), mainBox);
    }) 
   
});


//scrolling on select of flight pricing
function scrollToTop(target, scrollMargin){
    $('html, body').animate({ scrollTop: $(target).offset().top - scrollMargin }, 500);    
}

function animationScroll(element, mainBox){    
    var $prevBlock =   $(element).parents('.card').prevAll('.card');
   // $(mainBox).addClass('boxSpinLoad');
    if($prevBlock.length > 0){
        scrollToTop($prevBlock, 0);
        setTimeout(function(){
            scrollToTop(element, 0);
            $(mainBox).removeClass('boxSpinLoad');            
        }, 600);
    }
    else{
        scrollToTop(element, 0);
        $(mainBox).removeClass('boxSpinLoad');
        
    }
}

/*open seatmap accordian start */
function showSeatMap(accordBtn){ 
    var mainBox = $(accordBtn).attr('data-target');                  
    var rangeViewport = $(mainBox).find('.availableSeats .active .sOuterViewport');
    var mrangeViewport = $(mainBox).find('.availableSeats .active .mViewPort');

    //loading will change in dynamic 
    $(mainBox).find('.card-body').addClass('boxSpinLoad');
    setTimeout(function(){$(mainBox).find('.card-body').removeClass('boxSpinLoad')},700);
    //loading will change in dynamic 

    $('.accordion').on('shown.bs.collapse', function (){             
        mPassSlider(mainBox);
        seatsSlider(mainBox, rangeViewport, mrangeViewport);        
        onscrollRangeSelect(mainBox, rangeViewport, mrangeViewport);
        selectPassenger(mainBox, rangeViewport, mrangeViewport);
        $(rangeViewport).find('button').each(function(){            
            if(!$(this).hasClass('noAvailSeat')){
                $(this).popover({
                    container: '.popOverContainer',                            
                    html: true,
                    content:'<div class="popover-body"></div>',                  
                    placement : 'auto',
                })
            }            
        })
        
    })
}
/*open seatmap accordian end */

/*main seat area viewport and slider for mobile and desktop start */
function seatsSlider(mainBox, rangeViewport, mrangeViewport){
    var rArray=[], rmaxHeight=0;
    var $seatAreaRange = $(mainBox).find('.availableSeats .active .range');    
    var screenWidth = window.innerWidth;
    $(rangeViewport).find('.exitRow').outerHeight('auto');    
    if(screenWidth < 768){ 
        var a = 0; 
        $(mrangeViewport).width(screenWidth-45);
        $(rangeViewport).find('.srow').each(function(){               
            a = a + $(this).width();
        })
        $(rangeViewport).width(a); 
     }
     else{
        $(rangeViewport).width('auto');
        $(mrangeViewport).width('auto');
     }  
    $seatAreaRange.each(function(){                       
        rArray.push($(this).outerHeight());           
        if(screenWidth < 768){           
            $(this).attr('data-value', $(this).position().left)
        }
        else{$(this).attr('data-value', $(this).position().top - $(rangeViewport).position().top)}
        rmaxHeight = Math.max.apply(null, rArray);
    })
    $(rangeViewport).height(rmaxHeight);
    if(screenWidth < 768){ 
        $(rangeViewport).find('.exitRow').outerHeight(rmaxHeight);
    }
   
}
/*main seat area viewport and slider for mobile and desktop end */

/*select range on scroll start*/
function onscrollRangeSelect(mainBox, rangeViewport, mrangeViewport){
    var vh = $(rangeViewport).height() - $(mainBox).find('.active .exitRow').height();
    var vw = $(mrangeViewport).find('.activeRange').width() ;    
    if(window.innerWidth > 767){        
        $(rangeViewport).scroll(function(){ 
            if($(this).scrollTop() < vh){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(1)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }       
            if($(this).scrollTop() >= vh){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(2)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollTop() >= vh*2){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(3)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollTop() >= vh*3){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(4)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollTop() >= vh*4){               
                $(mainBox).find('.active .seatsPreviewBody .range:eq(5)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollTop() >= vh*5){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(6)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
        })
    }
    else{
        $(mrangeViewport).scroll(function(){ 
            if($(this).scrollLeft() < vw){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(1)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }       
            if($(this).scrollLeft() >= vw){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(2)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollLeft() >= vw*2){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(3)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollLeft() >= vw*3){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(4)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollLeft() >= vw*4){               
                $(mainBox).find('.active .seatsPreviewBody .range:eq(5)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
            if($(this).scrollLeft() >= vw*5){                
                $(mainBox).find('.active .seatsPreviewBody .range:eq(6)').addClass('activeRange').siblings('.range').removeClass('activeRange');
            }
        })
    }

}
/*select range on scroll end*/


/*select passenger list and deck change from  start*/
function selectPassenger(mainBox, rangeViewport, mrangeViewport){
    $(mainBox).find('button.passDetails').click(function(){
        $(this).addClass('pactive').siblings('.passDetails').removeClass('pactive'); 
        $(mainBox).find('.selected').addClass('occupied').removeClass('selected');
        if($(this).hasClass('occupied')){            
            var selectedSeat = $(this).attr('data-value');
            var posTop = $(rangeViewport).find('[data-value="'+selectedSeat+'"]').parents('.range').attr('data-value');
            $(mainBox).find('[data-value="'+selectedSeat+'"]').addClass('selected').removeClass('occupied'); 
            if(window.innerWidth > 767){$(rangeViewport).animate({ scrollTop: posTop}, 500);}
            else{$(mrangeViewport).animate({ scrollLeft: posTop}, 500)}
            
        }
        if(window.innerWidth < 768){
            $(mainBox).find('.pList').animate({ scrollLeft: $(this).position().left - (window.innerWidth -  $(this).width() -30)}, 300)
        }
    })    
}
/*select passenger list and deck change end here*/

/*scroll animation on range click start here*/
function goToRange(element){ 
    var rangeViewport = $(element).parents('.card-body').find('.active .sOuterViewport');
    var heightScroll = $(rangeViewport).scrollTop(); 
    var heightVieport = $(rangeViewport).height();
    var target = $(element).attr('data-target');
    
    if(window.innerWidth > 767){
        if($(element).hasClass('nextBtn')){  
               
            $(rangeViewport).animate({ scrollTop: heightScroll+heightVieport}, 500);
            if(heightScroll >  $(rangeViewport).find('.range:last').attr('data-value') - heightVieport){
                  
                $('.nextBtn').css('visibility','hidden')
            }
        }
        if($(element).hasClass('prevBtn')){
            $(rangeViewport).animate({ scrollTop: heightScroll-heightVieport}, 500);
        }
        else{             
            var tPos = $(target).attr('data-value');
            rangeViewport = $(target).parents('.sOuterViewport');       
            $(element).addClass('activeRange').siblings('.range').removeClass('activeRange');
            $(rangeViewport).animate({ scrollTop: tPos}, 500);
        }
    }

    else{        
        var lPos = $(target).attr('data-value');      
        var mrangeViewport = $(target).parents('.mViewPort');       
        $(element).addClass('activeRange').siblings('.range').removeClass('activeRange');
        $(mrangeViewport).animate({ scrollLeft: lPos}, 500);
    }
    if($('body').hasClass('overlayOn')){
        $('body').removeClass('overlayOn');
        $(element).parents('.seatsPreview').removeClass('on');
    }
    
}
/*scroll animation on range click end here*/


function mPassSlider(mainBox){
    var screenWidth = window.innerWidth;
    var $passViewport = $(mainBox).find('.pViewport');
    var viewPortWidth = 0;
    if(screenWidth < 768){
        $passViewport.find('.passDetails').each(function(){            
            viewPortWidth =viewPortWidth + $(this).outerWidth();
        })
       $(mainBox).find('.pList').width(screenWidth);
       $passViewport.width(viewPortWidth+5);
        
    }
    else{
        $(mainBox).find('.pList').removeAttr('style');
        $passViewport.removeAttr('style');
    }
}

function openSlide(element, target){
    var $closeBtn = $(target).find('.closeIcon');
    $('body').addClass('overlayOn');
    $(target).addClass('on');
    
    $closeBtn.click(function(){
        $('body').removeClass('overlayOn');
        $(target).removeClass('on');
    })
}


//seat selection from popover
function selectSeat(element, price, currancy, seatNo){ 
    var $mainBox = $(element).parents('.card-body');
    if($(element).hasClass('occupied')){
        var occupiedVal = $(element).attr('data-value');
        $mainBox.find('.passDetails[data-value="'+occupiedVal+'"]').click();
    } 
    
    var $activePass = $mainBox.find('.pactive');
    var passName = $activePass.find('.pName').html();
    var $selectedSeat =$mainBox.find('.selected');
    var title='<button type="button"  class="closeIcon icon-close btn"><em class="sr-only">close</em></button>'+seatNo+' <span>Window</span><em>Weelchair accessible</em>';
    var ExitTitle='<button type="button"  class="closeIcon icon-close btn"><em class="sr-only">close</em></button><h4 class="h4 h4-one"><span class="icon-checkmark"></span>'+passName+'</h4>'+seatNo+' <span>Window</span><em>Weelchair accessible</em>';
    var seatContent = $('.seatContent').html();
    var selectFooter = '<span class="innerPrice">'+price +' ' + currancy+'</span><button type="button"  class="btn btn-dark selectSeat">Select this seat</button>';
    var exitFooter = '<span class="innerPrice">'+price +' ' + currancy+'</span><button type="button" class="btn btn-dark-transparent removeSeat">Remove selection</button>';
    var aExitSeat = $('.aexitSeat').html();
    $(element).on('inserted.bs.popover', function (){
        if($(element).hasClass('aExit')){            
            $('.popover').addClass('bigPop');
        }

    });
    
    $(element).on('shown.bs.popover', function (){
        $('body').addClass('on');
        if(window.innerWidth < 768){$('body').addClass('overlayOn');} 
        $('.popover-header').html(title);
        $('.popover-body').html(seatContent).find('.popover-footer').html(selectFooter);

        
        
        if($(element).hasClass('occupied')|| $(element).hasClass('selected')){ 
            $('.popover-header').html(ExitTitle);     
            $('.popover-body').find('.popover-footer').html(exitFooter); 
        }
        if($(element).hasClass('aExit')){
            $('.popover-body').html(aExitSeat).find('.popover-footer').html(selectFooter);
        }
        if($(element).hasClass('aExit occupied') || $(element).hasClass('aExit selected') ){            
            $('.popover-body').html(aExitSeat).find('.popover-footer').html(exitFooter);
        }

        $('.popover .btn').on('click', function(e){ 
            $('body').removeClass('overlayOn');
            var passBtnHtml='', seatHtml='';
            if($(this).hasClass('selectSeat')){                                
                $selectedSeat.removeClass('selected').find('.pCaption').remove();
                passBtnHtml ='<span class="pCaption" >'+seatNo+'</span><span class="pName">'+passName+'</span><br><span class="pSeat"><span class="icon-checkmark"></span>Selected </span><em class="charges" data-price="'+price+'">'+price+' '+ currancy+'</em>'
                seatHtml = '<abbr class="sr-only">'+seatNo+'</abbr><span class="pCaption">'+seatNo+'</span>'
                $mainBox.find('[data-value="'+seatNo+'"]').addClass('selected').html(seatHtml);
                $activePass.addClass('selected').attr('data-value', seatNo).html(passBtnHtml);
                
            } 
            if($(this).hasClass('removeSeat')){               
                $selectedSeat.removeClass('selected').find('.pCaption').remove();
                passBtnHtml ='<span class="pCaption" ></span><span class="pName">'+passName+'</span><br><span class="pSeat">No seat selected</span>';
                seatHtml = '<abbr class="sr-only">'+seatNo+'</abbr>';
                $mainBox.find('[data-value="'+seatNo+'"]').removeClass('selected').html(seatHtml);
                $activePass.removeClass('selected').attr('data-value', '').html(passBtnHtml);
                
            }
            subTotal($mainBox);            
            grandTotal($mainBox.parents('.accordion'));
            
            $('.popover').popover('hide');
            $('body').removeClass('on');       
        })             
    })
    

    // close popup on outside click
    $(document).on('mouseup', function(e) {
        if(!$(e.target).closest('.popover').length){                      
            $('.popover').popover('hide');
        }
    });

}

//addition of total price on sticky header 
function priceAnimation(lastPrice, totalPrice, $priceFp){    
    totalPrice = parseFloat(Math.round(totalPrice * 100) / 100).toFixed(2);
    var a =totalPrice.split(".")[0];
    var b= totalPrice.split(".")[1];
    $priceFp.prop('Counter',lastPrice).animate({
        Counter: a
    }, {
        duration: 500,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
    setTimeout(function(){
        $priceFp.html(a).next().html("."+b);
    }, 600) 
}


function subTotal($mainBox){
    var $priceFp = $mainBox.find('.priceDetails .fp');
    var lastPrice =  parseFloat($mainBox.find('.priceDetails').attr('data-price'));  
    var totalPrice = 0;
    $mainBox.find(".pList .passDetails").each(function(){
        if($(this).find('.charges').length > 0){
        totalPrice =totalPrice + parseFloat($(this).find('.charges').attr('data-price'));
        }
    })    
    $mainBox.find('.priceDetails').attr('data-price',totalPrice);
    if(totalPrice == 0){
        $priceFp.parents('.priceBlock').slideUp(300);
    }
    else{
        $priceFp.parents('.priceBlock').slideDown(300);
        priceAnimation(lastPrice, totalPrice, $priceFp);
    }
    
}

function grandTotal($mainAccordian){    
    var $priceFp = $('.grandTotal .priceDetails .fp');
    var lastPrice = parseFloat($('.grandTotal .priceDetails').attr('data-price'));
    var totalPrice = 0;
    
    $mainAccordian.find(".card-body").each(function(){
        if($(this).find('.pList .priceDetails').length > 0){
        totalPrice =totalPrice + parseFloat($(this).find('.pList .priceDetails').attr('data-price'));
        }
    })
    $('.grandTotal .priceDetails').attr('data-price',totalPrice);     
    if(totalPrice == 0){
        $priceFp.parents('.grandTotal').slideUp(300);
    }
    else{        
        $priceFp.parents('.grandTotal').slideDown(300);
        priceAnimation(lastPrice, totalPrice, $priceFp);
    }
    
}

function showNextFlight(element){   
    $('button[data-target="'+element+'"]').click();
}



function selectDeck(element){    
    var target = $(element).attr('href');
    var mainBox = $(element).parents('.card-body');
    $(mainBox).find('[rel="'+target+'"]').addClass('active boxSpinLoad').siblings().removeClass('active');
    var rangeViewport = $(mainBox).find('.availableSeats .active .sOuterViewport');
    var mrangeViewport  = $(mainBox).find('.availableSeats .active .mViewPort');
    setTimeout(function(){ 
        seatsSlider(mainBox, rangeViewport, mrangeViewport); 
        $(mainBox).find('[rel="'+target+'"]').removeClass('boxSpinLoad');
    }, 300);

    $(mainBox).find('.deckList  a').removeClass('active');       
    $(element).addClass('active');
}


$(window).bind('orientationchange', function(){ 
    var mainBox = $('.accordion .show');     
    var rangeViewport = $(mainBox).find('.availableSeats .active .sOuterViewport');
    var mrangeViewport  = $(mainBox).find('.availableSeats .active .mViewPort');
    setTimeout(function(){  
        mPassSlider(mainBox);
        seatsSlider(mainBox, rangeViewport, mrangeViewport);        
        onscrollRangeSelect(mainBox, rangeViewport, mrangeViewport);
        selectPassenger(mainBox, rangeViewport, mrangeViewport);
        if($('.popover').length > 0){
            $('.popover a.btn').click();
        }
    }, 100);

}); 


   



















