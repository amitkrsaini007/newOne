
$(document).ready(function() {
    
    //help tooltip script start from here 
    $(document).mouseup(function(e) {
        if(!$(e.target).is(".flightTooltip")) {
            $('span.flightTooltip').css({"visibility":"hidden","opacity":"0"});
        } 
    });
    $(".mb-tooltip").click(function(e){
        e.preventDefault();
        $(this).find("span.flightTooltip").css({"visibility":"visible","opacity":"1"}).find("#closeTooltip").click(function(e){
            e.preventDefault();
            $(this).parents('span.flightTooltip').css({"visibility":"hidden","opacity":"0"});
            e.stopPropagation();
        })            
    })
        
    
})

var stickyHeaderHeight = $('.fixedFlyDetail').height(); 
// function to show the full view details
function showAllPrice(element, className){
    event.preventDefault();
    $(element).parents('.fly-result').find('.detailsHeader').find('a').removeClass('active');   
    $(element).addClass('active');
    var mainBlock = $(element).parents('.or-f-details');
    applytinycarousel(mainBlock, className);  
    $(mainBlock).parents('.fly-result').find('.fly-view-data-viewdetails').hide();      
    $(mainBlock).find('.'+className).show(0, function(){
        //call scroll to top function here after slide down of flight price 
        var target = $(element).attr('href');                         
        scrollToTop(target, stickyHeaderHeight); 
        var flightID = $(element).parents('.md-details').attr('id');
        //go back to flight details
        $('.'+flightID).find('.goBackToFlight').attr('href',target).click(function(e){
            e.preventDefault();                                   
            scrollToTop(target, 0); 
            //accessability
            $(target).attr('tabindex','-1').focus();
        });     
        
    }).attr('tabindex','-1').focus(); 
    $(element).nextAll('.radiobtn').attr('tabindex','-1');   
    //set the width of block 
    setWidthOfListBlock(mainBlock, className);
    //call setHeight from bottom of each fare block
    setHeightFareClass(mainBlock, className);

    //jquery Tabs initialization for new flyview Details
    $(mainBlock).find('.'+className).find('.journeyBox').tabs({active: 0});
    $(mainBlock).find('.'+className).find('.innerJourneyBox').tabs({active: 1}); 
    if($(mainBlock).find('.'+className).find('.slider').length > 0){
        $(mainBlock).find('.'+className).find('.slider').tinycarousel({infinite:false, })
    }

}

function setWidthOfListBlock(mainBlock, className){
    var cell = $(mainBlock).find('.'+className).find('.listCol');
    var cellCount = $(mainBlock).find('.'+className).find('.listCol').length;
    var cellWidth = 100/cellCount-1;    
    $(cell).css('width',cellWidth+'%');
    if(cellCount == 1){ $(cell).addClass('singleList')}
}

function setHeightFareClass(mainBlock, className){
    var fareBlock = $(mainBlock).find('.'+className).find('.fareBlock');    
    var tableCount = fareBlock.length -1;    
    var cellCount = $(fareBlock).eq(tableCount).find('li').length;       
    var a = [];
    var b =[];     
    var x=0;
    for (var i = tableCount; i >= 0; i--){ 
        a=[];
        for(var j=0; j<cellCount; j++){
            var h = $(fareBlock).eq(i).find('li').eq(j).height();         
            if(h== null || h == undefined){ a.unshift(0); }
            else{a.push(h);}                 
        }   
        if(x==0){ b=a;}
        else {
            for(var k=0; k<cellCount; k++) {  
                b[k]=Math.max(a[k], b[k]);
            }
        }
        x++;           
    }   
    
    for(var i=tableCount;i>=0; i--){ 
        var d= $(fareBlock).eq(i).find('li').length;
        var n = cellCount -1;        
        for(var j=d-1; j>=0;j--){                     
            $(fareBlock).eq(i).find('li').eq(j).height(b[n]);
            n--;        
        }         
        var mbHeight = $(fareBlock).parents('.fareClassDetails').height();        
        var fHeight = $(fareBlock).eq(i).outerHeight();      
        var mTop =  mbHeight - fHeight; 
        $(fareBlock).eq(i).css('margin-top', mTop); 
                
    }  

    if( $(mainBlock).find('.'+className).find('.prmo').length > 0){
        $(mainBlock).find('.'+className).find('.prmo').outerHeight(mbHeight);        
    }
} 



//scrolling on select of flight pricing
function scrollToTop(target, scrollMargin){  
    $('html, body').animate({ scrollTop: $(target).offset().top - scrollMargin }, 600);    
}


// fixed and static the fixed price details on window scroll
var stickyHeader = $('.fixedFlyDetail');
var topPosStiky = $(stickyHeader).offset().top;
//var topPosSummary = $('.tripSummary').offset().top;
//window.pageYOffset

window.onscroll = function() {stickyHeaderScroll()};
function stickyHeaderScroll() { 
    if (window.pageYOffset >= topPosStiky) {
        $('.fixedFlyDetail').addClass('sticky');
    } else {
        $('.fixedFlyDetail').removeClass('sticky');
    }
    if(window.pageYOffset >= $('.tripSummary').offset().top-100){
        $('.fixedFlyDetail').fadeOut(500);
        
    } 
    else if(window.pageYOffset < $('.tripSummary').offset().top  && $('.fixedFlyDetail').hasClass('sticky')){
        $('.fixedFlyDetail').fadeIn(500);
        
        
    }     
}



//add flight details on top Sticky header it is removeable if developer don't want use it
function addFlightDetais(element, depDate, arrDate, depCode, arrCode, depTime, arrTime, extDay, price){ 
    
    if(!$(element).hasClass('selected')){
        var flightResultId = $(element).parents('.md-details').attr('id'); 
        var flightId = $(element).parents('.or-f-details').attr('id');  
        var $flyViewDetails = $(element).parents('.fly-view-data-viewdetails');  
        selectClassBtn(element);
        var lastPrice;        
       //reset price function calling
        resetOldPrice(element, flightId);        
        $flyViewDetails.slideUp(500);
        scrollToTop($("#"+flightId), stickyHeaderHeight); 
        $("#"+flightResultId).addClass('selected');
        if($("#"+flightResultId).next().hasClass('md-details')){
            setTimeout(function(){ 
                scrollToTop($("#"+flightResultId).next('.md-details'), 0);
            }, 1000);
        }
        else{
            var flightCount= $('.md-details').length;
            var selectedFlight = $('.md-details.selected').length;            
            if(flightCount == selectedFlight){
                showTripSummary($('#continueBtn'));
            }            
        }
        
        //accessability code 
        $("#"+flightId).find('.radiobtn').removeAttr('tabindex');
        
         
    }


   
     
}

function selectClassBtn(element){
    $(element).parents('.md-details').find('.yellowBtn').removeClass("selected");
    $(element).addClass("selected");
}





//attach event on view Next Fares promo of business
$('.economyFare .viewNextFares').click(function(){
    var element = $(this).parents('.or-f-details').find('.radiobtn').eq(1);    
    showAllPrice(element, 'businessFare');
})
//attach event on view Next Fares promo of first 
$('.businessFare .viewNextFares').click(function(){
    var element = $(this).parents('.or-f-details').find('.radiobtn').eq(2);
    showAllPrice(element, 'firstFare')
})



/*
$(document).ready(function() { 
    //change the text of continue btn
    if($('#continueBtn').hasClass('disabled') && $('.departure').length > 0 && $('.return').length > 0){
        $('#continueBtn').html('Please select your departure and return flight');
    }
    else if($('#continueBtn').hasClass('disabled') && $('.departure').length > 0 && $('.return').length < 1){
        $('#continueBtn').html('Please select departure flight');
    } 

})*/

//removeable script on show trip summary on continue click
function showTripSummary(element){ 
        $(element).hide();
        $('.tripSummary').css('height','auto');
        var target = $('.tripSummary');

        //set time out is for temporary to showing the price effect on the sticky bar 
        setTimeout(function(){scrollToTop(target, 0); },500);
        
        //remove when development start
        setTimeout(function(){            
            $('.tripSummary').removeClass('loading');
            $('.tripSummary').attr('tabindex','-1').focus()
        }, 1000);
}







//removeable script on show trip summary on continue click
function showMoreFlight(element){
    $(element).parents('.showMorebtn').addClass('loading');
    setTimeout(function(){ 
        $(element).parents('.md-details').find('.or-f-details:hidden').slideDown();
        $(element).parents('.showMorebtn').removeClass('loading').hide();

    }, 500); 

}




//go back to flight details

$('.remove-flights a').click(function(event){
    event.preventDefault();
    var target = $(this).attr('href');                         
    scrollToTop(target, stickyHeaderHeight); 
    //accessability
    $(target).attr('tabindex','-1').focus();
})





//reset old price 
function resetOldPrice(element, flightId){
     //slide up the fly view details and main price change
     if($(element).parents('.fly-result').find('a.selected').length > 0){
        var relPrice = $(element).parents('.fly-result').find('a.selected').find('.priceDetails').attr('data-value');
        var a = $(element).parents('.fly-result').find('a.selected').find('.currancy').html();
        var b =relPrice.split(".")[0];
        var c= relPrice.split(".")[1];
        var relPriceHtml = "From <br/><span class='currancy'>"+a+"</span><span class='number'>"+b+"</span> <sup class='decimal'>"+c+"</sup></span>";
        $(element).parents('.fly-result').find('a.selected').find('.priceDetails').html(relPriceHtml);
        $(element).parents('.fly-result').find('a.selected').removeClass('selected');
     }
     
     var selectedPrice = "Fare Selected<br/>"+$(element).parents('.bottomItem').find('.priceDetails').html();
     $("#"+flightId + " .active .priceDetails").html(selectedPrice);
     $("#"+flightId + " .active").addClass('selected');

    //$(element).parents('.fly-view-data-viewdetails').slideUp(500);
    //scrollToTop($("#"+flightId), 0);
    
}


//close fly view details 
function closeFlyDetails(element){
    event.preventDefault();    
    $(element).parents('.fly-view-data-viewdetails').slideUp(500);
    $(element).parents('.or-f-details').find('a.active').removeClass('active').focus().nextAll('.radiobtn').removeAttr('tabindex');

}


//go Back to modify search
function goToModify(){
    var target = $("#modifySearch");
    scrollToTop(target, 12);
    target.click();
}



//if Experience list item more than three than apply tinycarousel
function applytinycarousel(mainBlock, className){   
    var listItemLength =  $(mainBlock).find('.'+className).find('.journeyBox ul:first li').length;    
    var listItemBox = $(mainBlock).find('.'+className).find('.journeyBox');
    var listItemHtml = $(listItemBox).find('ul:first').html();

    if(listItemLength > 3 && !$(listItemBox).hasClass('tinycarousel')){         
        $(listItemBox).find('ul:first').remove();
        $(listItemBox).prepend("<div class='slider'><a class='buttons prev' href='#'>previous</a><div class='viewport'><ul class='overview'>"+listItemHtml+"</ul></div><a class='buttons next' href='#'>next</a></div>");
        $(listItemBox).addClass('tinycarousel');
    }
}

var serachFromTop =$('.modify-search').offset().top ;
$(window).scroll(function(){
    
    if($(window).scrollTop() >= serachFromTop){
     $('.modify-search').addClass('fixed');
    }
     
     else {$('.modify-search').removeClass('fixed');}
   });