
$(document).ready(function() { 
    //jquery Tabs initialization for new flyview Details
    $('.journeyBox, .innerJourneyBox').tabs({
        active: 2
      }); 
})

var stickyHeaderHeight = $('.fixedFlyDetail').height(); 
// function to show the full view details
function showAllPrice(element, className){
    event.preventDefault();
    $(element).parents('.fly-result').find('.detailsHeader').find('a').removeClass('active');
    $(element).addClass('active');
    var mainBlock = $(element).parents('.or-f-details');
    $(mainBlock).parents('.fly-result').find('.fly-view-data-viewdetails').hide();
      
    $(mainBlock).find('.'+className).show(0, function(){
        //call scroll to top function here after slide down of flight price 
        var target = $(element).attr('href');                         
        scrollToTop(target, stickyHeaderHeight); 
    });    
    //set the width of block 
    setWidthOfListBlock(mainBlock, className);
    //call setHeight from bottom of each fare block
    setHeightFareClass(mainBlock, className);

}

function setWidthOfListBlock(mainBlock, className){
    var cell = $(mainBlock).find('.'+className).find('.listCol');
    var cellCount = $(mainBlock).find('.'+className).find('.listCol').length;
    var cellWidth = 100/cellCount-1;    
    $(cell).css('width',cellWidth+'%');
    if(cellCount == 1){ $(cell).addClass('singleList')}
}

function setHeightFareClass(mainBlock, className){
    var fareBlock = $(mainBlock).find('.'+className).find('.fareBlock');    
    var tableCount = fareBlock.length -1;    
    var cellCount = $(fareBlock).eq(tableCount).find('li').length;       
    var a = [];
    var b =[];     
    var x=0;
    for (var i = tableCount; i >= 0; i--){ 
        a=[];
        for(var j=0; j<cellCount; j++){
            var h = $(fareBlock).eq(i).find('li').eq(j).height();         
            if(h== null || h == undefined){ a.unshift(0); }
            else{a.push(h);}                 
        }   
        if(x==0){ b=a;}
        else {
            for(var k=0; k<cellCount; k++) {  
                b[k]=Math.max(a[k], b[k]);
            }
        }
        x++;           
    }   
    
    for(var i=tableCount;i>=0; i--){ 
        var d= $(fareBlock).eq(i).find('li').length;
        var n = cellCount -1;        
        for(var j=d-1; j>=0;j--){                     
            $(fareBlock).eq(i).find('li').eq(j).height(b[n]);
            n--;        
        }         
        var mbHeight = $(fareBlock).parents('.fareClassDetails').height();        
        var fHeight = $(fareBlock).eq(i).outerHeight();      
        var mTop =  mbHeight - fHeight; 
        $(fareBlock).eq(i).css('margin-top', mTop); 
                
    }  

    if( $(mainBlock).find('.'+className).find('.prmo').length > 0){
        $(mainBlock).find('.'+className).find('.prmo').outerHeight(mbHeight);        
    }
} 



//scrolling on select of flight pricing
function scrollToTop(target, scrollMargin){  
    $('html, body').animate({ scrollTop: $(target).offset().top - scrollMargin }, 600);    
}

// fixed and static the fixed price details on window scroll
var stickyHeader = $('.fixedFlyDetail');
var topPosStiky = $(stickyHeader).offset().top;
//var topPosSummary = $('.tripSummary').offset().top;
//window.pageYOffset

window.onscroll = function() {stickyHeaderScroll()};
function stickyHeaderScroll() { 
        if (window.pageYOffset >= topPosStiky) {
            $('.fixedFlyDetail').addClass('sticky');
        } else {
            $('.fixedFlyDetail').removeClass('sticky');
        }
        if(window.pageYOffset >= $('.tripSummary').offset().top-100){
            $('.fixedFlyDetail').fadeOut(500);
           
        } 
        else if(window.pageYOffset < $('.tripSummary').offset().top  && $('.fixedFlyDetail').hasClass('sticky')){
            $('.fixedFlyDetail').fadeIn(500);
            
            
        }     
}





//add flight details on top Sticky header it is removeable if developer don't want use it
function addFlightDetais(element, depDate, arrDate, depCode, arrCode, depTime, arrTime, extDay, price){
    if(!$(element).hasClass('selected')){
        var flightId = $(element).parents('.or-f-details').attr('id');    
        selectClassBtn(element);
        var lastPrice;
        if(extDay>0){
            extDay = "<span class='extDay'>+"+extDay+" day</span>";
        }
       
        
        
        if($(element).parents('.md-details').hasClass('departure')){
            var  flightDetail ="<div class='sel-des'><span class='ur-icons u-icons'></span><span class='dep-details'><span class='date'>"+depDate
            +"</span><span class='time-head'><span class='time'>"+depTime+" "+depCode+"</span></span></span><span class='ttl-time'><span class='time-icon'></span></span><span class='arr-details'><span class='date'>"+arrDate
            +"</span><span class='time-head'><span class='time'>"+arrTime+" "+arrCode+"</span>"+extDay+"</span></span></div>";

            //add the departure flight price on sticky header
            lastPrice = parseFloat($(stickyHeader).find('.totalPrice').attr('data-depature-value'));
            $(stickyHeader).find('.totalPrice').attr('data-depature-value',price);
            //update the departure flight details on sticky header
            if(flightId != $(stickyHeader).find('.col-lg-4 ').eq(0).attr('data-depature-value')){       
                $(stickyHeader).find('.col-lg-4 ').eq(0).attr('data-depature-value',flightId);
                $(stickyHeader).find('.col-lg-4').eq(0).fadeOut(function(){
                    $(this).html(flightDetail).fadeIn();
                });
                // add class departureAdd to change continue btn 
                $(stickyHeader).addClass('departureAdd')

                
                if(!$(stickyHeader).hasClass('returnAdd')){            
                    var rFlightDetail = "<div class='sel-des'><span class='ur-icons r-icons'></span><span class='txtNew'>Please Select Your Return Flight</span></div>";
                    $(stickyHeader).find('.col-lg-4 ').eq(1).fadeOut(function(){
                        $(this).html(rFlightDetail).fadeIn();
                    });                   
                                        
                }
            }
            //call scroll to top function here after slide down of flight price 
            //remove set time out when this will implement in development
            if($("#return").length > 0){    
                setTimeout(function(){ 
                    scrollToTop($("#return"), stickyHeaderHeight);
                }, 2000); 
               
            }
            
        }
        else{ 
            var  flightDetail ="<div class='sel-des'><span class='ur-icons r-icons'></span><span class='dep-details'><span class='date'>"+depDate
            +"</span><span class='time-head'><span class='time'>"+depTime+" "+depCode+"</span></span></span><span class='ttl-time'><span class='time-icon'></span></span><span class='arr-details'><span class='date'>"+arrDate
            +"</span><span class='time-head'><span class='time'>"+arrTime+" "+arrCode+"</span>"+extDay+"</span></span></div>";

            //add the return flight price on sticky header
            lastPrice = parseFloat($(stickyHeader).find('.totalPrice').attr('data-return-value'));
            $(stickyHeader).find('.totalPrice').attr('data-return-value',price); 
            //update the return flight details on sticky header       
            if(flightId != $(stickyHeader).find('.col-lg-4 ').eq(1).attr('data-depature-value')){ 
                $(stickyHeader).addClass('returnAdd');
                $(stickyHeader).find('.col-lg-4 ').eq(1).attr('data-depature-value',flightId);
                $(stickyHeader).find('.col-lg-4 ').eq(1).fadeOut(function(){
                    $(this).html(flightDetail).fadeIn();
                });
            }
            
        }    
        var totalPrice = parseFloat($(stickyHeader).find('.totalPrice').attr('data-value'));
        stickyPriceDetails(price, lastPrice, totalPrice);
    }


    // change continue btn text and style    
    if($(stickyHeader).hasClass('departureAdd') && !$(stickyHeader).hasClass('returnAdd') && $('.return').length > 0){        
        $('#continueBtn').html('Please select your return flight');        
    }
    else if(!$(stickyHeader).hasClass('departureAdd') && $(stickyHeader).hasClass('returnAdd') && $('.return').length > 0){        
        $('#continueBtn').html('Please select your departure flight');
    }
    else if($(stickyHeader).hasClass('departureAdd') && $(stickyHeader).hasClass('returnAdd') && $('.return').length > 0){       
        showTripSummary($('#continueBtn'));
    }
    else if( $(stickyHeader).hasClass('departureAdd') && $('.return').length == 0){   
        showTripSummary($('#continueBtn'));
        
    }
     
}

function selectClassBtn(element){
    $(element).parents('.md-details').find('.yellowBtn').removeClass("selected");
    $(element).addClass("selected");
}


//addition of total price on sticky header 
function stickyPriceDetails(price, lastPrice, totalPrice){   
    totalPrice = totalPrice - lastPrice + price;
    $(stickyHeader).find('.totalPrice').attr('data-value',totalPrice);         
    $('.totalPrice').prop('Counter',lastPrice).animate({
        Counter: totalPrice
    }, {
        duration: 400,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
    setTimeout(function(){
        totalPrice = parseFloat(Math.round(totalPrice * 100) / 100).toFixed(2);
        var a =totalPrice.split(".")[0];
        var b= totalPrice.split(".")[1];             
        //$('.sel-Total .ttl').fadeOut();
        $('.sel-Total .totalPrice').html(a).next().html("."+b);
       // $('.sel-Total .ttl').fadeIn();
    }, 500)

   
    ppAmoutCal(totalPrice);

}


//attach event on view Next Fares promo of business
$('.economyFare .viewNextFares').click(function(){
    var element = $(this).parents('.or-f-details').find('.radiobtn').eq(1);    
    showAllPrice(element, 'businessFare');
})
//attach event on view Next Fares promo of first 
$('.businessFare .viewNextFares').click(function(){
    var element = $(this).parents('.or-f-details').find('.radiobtn').eq(2);
    showAllPrice(element, 'firstFare')
})






//removeable script on show trip summary on continue click
function showTripSummary(element){ 
        $(element).hide();
        $('.tripSummary').css('height','auto');
        var target = $('.tripSummary');

        //set time out is for temporary to showing the price effect on the sticky bar 
        setTimeout(function(){scrollToTop(target, 0); },2000);
        
        //remove when development start
        setTimeout(function(){            
            $('.tripSummary').removeClass('loading');
        }, 3000);
}



$(document).ready(function() { 
//change the text of continue btn
    if($('#continueBtn').hasClass('disabled') && $('.departure').length > 0 && $('.return').length > 0){
        $('#continueBtn').html('Please select your departure and return flight');
    }
    else if($('#continueBtn').hasClass('disabled') && $('.departure').length > 0 && $('.return').length < 1){
        $('#continueBtn').html('Please select departure flight');
    } 

})


//removeable script on show trip summary on continue click
function showMoreFlight(element){
    $(element).parents('.showMorebtn').addClass('loading');
    setTimeout(function(){ 
        $(element).parents('.md-details').find('.or-f-details:hidden').slideDown();
        $(element).parents('.showMorebtn').removeClass('loading').hide();

    }, 500); 

}


 /*new filter script start*/
$(document).ready(function() { 
    $('.fl-link').click(function(){
        var target = $(this).parents('.w-r-h');                         
        scrollToTop(target, 52); 
        if($(this).hasClass('collapsed')){
            $('body').addClass('fOpen');
        }
        else{
            $('body').removeClass('fOpen');
        }
    })
    $('.filterContet .close').click(function(){
        $('.fl-link').click();
    })   
})
/*new filter script end*/

function ppAmoutCal(totalPrice){
    var emiAmount =  parseFloat(Math.round((totalPrice/6) * 100) / 100).toFixed(2);
    $('.ppBottomBanner').find('.ppAmount').html(emiAmount);
    
}