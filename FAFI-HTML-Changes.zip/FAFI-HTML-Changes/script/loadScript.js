
///*loading script for index page */
$( window ).load(function(){
	$('.mainLoading').hide();
})




$( window ).load(function(){
		
	$(".w-nav .a-left, .w-nav .a-right").click(function(){
			$(this).parents('.w-nav').addClass('loading').prepend("<span class='smallLoader'></span>");
			setTimeout(function(){ 
				$('.w-nav').removeClass("loading").find(".smallLoader").remove();  
        	}, 500); 
			
	})

	$('a.radiobtn').click(function(){
		$(this).parents('.or-f-details').find('.fareDetails').addClass('loading').prepend("<span class='smallLoader'></span>");
		

			setTimeout(function(){ 
				$('.or-f-details .fareDetails').removeClass("loading").find(".smallLoader").remove(); 
				$('.or-f-details .fareDetails').hide().fadeIn(500);
			
        	}, 500); 
	})
	

	
	
	
	
	
})

///*loading script for index page */